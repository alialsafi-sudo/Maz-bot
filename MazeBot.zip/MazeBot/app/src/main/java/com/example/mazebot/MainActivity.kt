package com.example.mazebot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val REQ_CAPTURE = 100

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        l.addView(TextView(this).apply {
            text = "▶ تشغيل/إيقاف البوت\n🎯 اسحبه فوق زر (المرحلة التالية)\n🐞 لقطة تشخيص (أخضر=حر، أحمر=محجوب)\n✖ إغلاق"
            textSize = 16f
        })
        l.addView(Button(this).apply {
            text = "1) صلاحية الظهور فوق التطبيقات"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        l.addView(Button(this).apply {
            text = "2) تفعيل خدمة إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        l.addView(Button(this).apply {
            text = "3) بدء الأزرار العائمة"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) return@setOnClickListener
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
            }
        })
        setContentView(l)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            finish()
        }
    }
}
