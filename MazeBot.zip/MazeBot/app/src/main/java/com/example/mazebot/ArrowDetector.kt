package com.example.mazebot

import android.graphics.Bitmap

data class Arrow(
    val cx: Int, val cy: Int,        // مركز رأس السهم (نقطة النقر)
    val tipX: Int, val tipY: Int,    // طرف السهم
    val dx: Int, val dy: Int         // اتجاه السهم
)

/**
 * كشف الأسهم بالشكل: رأس السهم مثلث يتسع صف بعد صف ثم يتصل بخط رفيع (الذيل).
 * الزوايا والتقاطعات والجدران لا تعطي هذا النمط فلا تُعتبر أسهماً.
 */
class ArrowDetector(
    private val tr: Int = 107, private val tg: Int = 79, private val tb: Int = 53,
    private val tolerance: Int = 55,
    private val regionTop: Float = 0.14f,      // تجاهل شريط الأعلى (أيقونات اللعبة)
    private val regionBottom: Float = 0.90f    // تجاهل الأسفل
) {
    private var w = 0
    private var h = 0
    private var y0 = 0
    private var y1 = 0
    private var thick = 4
    private var px = IntArray(0)
    private var mask = BooleanArray(0)
    private var obst = BooleanArray(0)      // كل الخطوط: بني + برتقالي (تلميح) + أحمر (خطأ)

    private fun isBrown(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return Math.abs(r - tr) < tolerance && Math.abs(g - tg) < tolerance && Math.abs(b - tb) < tolerance
    }

    private fun at(x: Int, y: Int) = x in 0 until w && y in y0 until y1 && mask[y * w + x]
    private fun obstAt(x: Int, y: Int) = x in 0 until w && y in y0 until y1 && obst[y * w + x]

    private fun isOther(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        val orange = r >= 205 && g in 140..215 && b <= 140 && (r - b) > 110
        val red = r in 150..235 && g <= 110 && b <= 110
        return orange || red
    }

    private fun estimateThickness(): Int {
        val hist = IntArray(30)
        for (y in y0 until y1 step 3) {
            var run = 0
            for (x in 0 until w) {
                if (mask[y * w + x]) run++
                else { if (run in 2..29) hist[run]++; run = 0 }
            }
        }
        var best = 4; var bc = 0
        for (i in 2..29) if (hist[i] > bc) { bc = hist[i]; best = i }
        return best
    }

    /** عرض الصف العمودي على الاتجاه عند (cx,cy)؛ -1 إذا غير مركزي أو غير صالح */
    private fun rowWidth(cx: Int, cy: Int, ppx: Int, ppy: Int, cap: Int): Int {
        if (!at(cx, cy)) return -1
        var a = 0; while (a < cap && at(cx + ppx * (a + 1), cy + ppy * (a + 1))) a++
        var b = 0; while (b < cap && at(cx - ppx * (b + 1), cy - ppy * (b + 1))) b++
        if (a >= cap || b >= cap) return -1
        if (Math.abs(a - b) > 2) return -1
        return a + b + 1
    }

    private fun checkHead(x: Int, y: Int, dx: Int, dy: Int): Arrow? {
        val t = thick
        val lmax = 5 * t + 6
        val cap = 4 * t + 3
        val ppx = -dy; val ppy = dx
        val widths = IntArray(lmax + 2)
        var hRow = -1
        var j = 0
        while (j < lmax) {
            val ww = rowWidth(x - dx * j, y - dy * j, ppx, ppy, cap)
            if (ww < 0) return null
            widths[j] = ww
            if (j > 0 && ww < widths[j - 1] - 1) { hRow = j - 1; break }
            if (j > 0 && ww - widths[j - 1] > t + 3) return null
            j++
        }
        if (hRow < 3) return null
        var wmax = 0
        for (i in 0..hRow) if (widths[i] > wmax) wmax = widths[i]
        if (wmax < maxOf(2 * t, t + 4)) return null              // الرأس أعرض من الخط
        if (widths[0] > t + 1) return null                        // الطرف حاد
        if ((wmax - widths[0]).toFloat() / hRow < 0.7f) return null  // يتسع تدريجياً
        for (k in 1..3) {                                         // بعد القاعدة: ذيل رفيع
            val sw = rowWidth(x - dx * (hRow + k), y - dy * (hRow + k), ppx, ppy, cap)
            if (sw < 1 || sw > t + 3) return null
        }
        return Arrow(x - dx * (hRow / 2), y - dy * (hRow / 2), x, y, dx, dy)
    }

    fun findFreeArrows(bmp: Bitmap): List<Arrow> = findArrows(bmp).filter { !isBlocked(it) }

    fun findArrows(bmp: Bitmap): List<Arrow> {
        w = bmp.width; h = bmp.height
        y0 = (h * regionTop).toInt(); y1 = (h * regionBottom).toInt()
        if (px.size != w * h) { px = IntArray(w * h); mask = BooleanArray(w * h); obst = BooleanArray(w * h) }
        bmp.getPixels(px, y0 * w, w, 0, y0, w, y1 - y0)
        for (y in y0 until y1) for (x in 0 until w) {
            val i = y * w + x
            val br = isBrown(px[i])
            mask[i] = br
            obst[i] = br || isOther(px[i])
        }
        thick = estimateThickness()

        val dirs = arrayOf(intArrayOf(0, 1), intArrayOf(0, -1), intArrayOf(1, 0), intArrayOf(-1, 0))
        val out = ArrayList<Arrow>()
        for (y in y0 until y1) for (x in 0 until w) {
            if (!mask[y * w + x]) continue
            for (d in dirs) {
                if (at(x + d[0], y + d[1])) continue          // الطرف: بعده فراغ
                val a = checkHead(x, y, d[0], d[1]) ?: continue
                var dup = false
                for (o in out) {
                    if (o.dx == a.dx && o.dy == a.dy &&
                        Math.abs(o.tipX - a.tipX) + Math.abs(o.tipY - a.tipY) <= 5) { dup = true; break }
                }
                if (!dup) out.add(a)
            }
        }
        return out
    }

    /** فحص العائق: خط بكسلات أمام الطرف. أي بكسل بني => محجوب */
    fun isBlocked(a: Arrow, gap: Int = maxOf(2, thick / 2 + 1), lookAhead: Int = 1500): Boolean {
        val ppx = -a.dy; val ppy = a.dx
        for (i in gap..lookAhead) {
            val x = a.tipX + a.dx * i; val y = a.tipY + a.dy * i
            if (x !in 0 until w || y !in y0 until y1) return false
            for (o in -1..1) if (obstAt(x + ppx * o, y + ppy * o)) return true
        }
        return false
    }
}
