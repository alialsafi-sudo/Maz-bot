package com.example.mazebot

import android.graphics.Bitmap

data class Arrow(
    val cx: Int, val cy: Int,        // مركز رأس السهم (نقطة النقر)
    val tipX: Int, val tipY: Int,    // طرف السهم
    val dx: Int, val dy: Int         // اتجاه السهم
)

class ArrowDetector(
    // لون الخطوط البني (الجدران والأسهم) - عدّله إذا لزم
    private val tr: Int = 107, private val tg: Int = 79, private val tb: Int = 53,
    private val tolerance: Int = 45
) {
    private var w = 0
    private var h = 0
    private var thick = 6
    private var mask = BooleanArray(0)

    private fun isBrown(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return Math.abs(r - tr) < tolerance && Math.abs(g - tg) < tolerance && Math.abs(b - tb) < tolerance
    }

    private fun at(x: Int, y: Int) = x in 0 until w && y in 0 until h && mask[y * w + x]

    /** قياس سماكة الخط تلقائياً (أكثر عرض تكراراً) */
    private fun estimateThickness(): Int {
        val hist = IntArray(40)
        for (y in 0 until h step 3) {
            var run = 0
            for (x in 0 until w) {
                if (mask[y * w + x]) run++
                else { if (run in 2..39) hist[run]++; run = 0 }
            }
        }
        var best = 6; var bc = 0
        for (i in 2..39) if (hist[i] > bc) { bc = hist[i]; best = i }
        return best
    }

    /** الأسهم الحرة فقط */
    fun findFreeArrows(bmp: Bitmap): List<Arrow> = findArrows(bmp).filter { !isBlocked(it) }

    fun findArrows(bmp: Bitmap): List<Arrow> {
        w = bmp.width; h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        mask = BooleanArray(w * h) { isBrown(px[it]) }

        thick = estimateThickness()
        val k = maxOf(thick + 2, (thick * 1.8f).toInt())

        // صورة تكاملية => تآكل سريع: يبقى فقط ما هو أعرض من الخط (رؤوس الأسهم)
        val integ = IntArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                if (mask[y * w + x]) row++
                integ[(y + 1) * (w + 1) + (x + 1)] = integ[y * (w + 1) + (x + 1)] + row
            }
        }
        val core = BooleanArray(w * h)
        for (y in 0..h - k) for (x in 0..w - k) {
            val s = integ[(y + k) * (w + 1) + x + k] - integ[y * (w + 1) + x + k] -
                    integ[(y + k) * (w + 1) + x] + integ[y * (w + 1) + x]
            if (s == k * k) core[(y + k / 2) * w + x + k / 2] = true
        }

        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        val out = ArrayList<Arrow>()
        val ddx = intArrayOf(1, -1, 0, 0)
        val ddy = intArrayOf(0, 0, 1, -1)
        for (i in core.indices) {
            if (!core[i] || seen[i]) continue
            var sp = 0; stack[sp++] = i; seen[i] = true
            var sx = 0L; var sy = 0L; var n = 0
            while (sp > 0) {
                val p = stack[--sp]; val x = p % w; val y = p / w
                sx += x; sy += y; n++
                for (d in 0..3) {
                    val nx = x + ddx[d]; val ny = y + ddy[d]
                    if (nx in 0 until w && ny in 0 until h) {
                        val q = ny * w + nx
                        if (core[q] && !seen[q]) { seen[q] = true; stack[sp++] = q }
                    }
                }
            }
            if (n < 2 || n > k * k * 3) continue
            direction((sx / n).toInt(), (sy / n).toInt())?.let { out.add(it) }
        }
        return out
    }

    /** الذيل = الجهة الأطول امتداداً من مركز الرأس؛ السهم يشير للعكس */
    private fun direction(cx: Int, cy: Int): Arrow? {
        val dirs = arrayOf(intArrayOf(0, -1), intArrayOf(0, 1), intArrayOf(-1, 0), intArrayOf(1, 0))
        val runs = IntArray(4)
        for ((i, d) in dirs.withIndex()) {
            var r = 0
            while (r < 400 && at(cx + d[0] * r, cy + d[1] * r)) r++
            runs[i] = r
        }
        var tail = 0
        for (i in 1..3) if (runs[i] > runs[tail]) tail = i
        val sorted = runs.sortedDescending()
        if (sorted[0] < sorted[1] * 1.15) return null
        val dx = -dirs[tail][0]; val dy = -dirs[tail][1]
        var tx = cx; var ty = cy
        while (at(tx + dx, ty + dy)) { tx += dx; ty += dy }
        return Arrow(cx, cy, tx, ty, dx, dy)
    }

    /** فحص العائق أمام السهم: أي بكسل بني على الخط الأمامي => محجوب */
    fun isBlocked(a: Arrow, gap: Int = maxOf(2, thick / 2), lookAhead: Int = 700): Boolean {
        val px = -a.dy; val py = a.dx
        for (i in gap..lookAhead) {
            val x = a.tipX + a.dx * i; val y = a.tipY + a.dy * i
            if (x !in 0 until w || y !in 0 until h) return false
            for (o in -1..1) if (at(x + px * o, y + py * o)) return true
        }
        return false
    }
}
