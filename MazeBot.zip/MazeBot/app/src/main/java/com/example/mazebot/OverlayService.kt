package com.example.mazebot

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.Button

class DebugView(c: Context) : View(c) {
    var items: List<Pair<Arrow, Boolean>> = emptyList()
    private val ok = Paint().apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 4f }
    private val bad = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 4f }
    override fun onDraw(cv: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        cv.translate(-loc[0].toFloat(), -loc[1].toFloat())   // تعويض إزاحة النافذة (شريط الحالة)
        for ((a, blocked) in items) {
            val p = if (blocked) bad else ok
            cv.drawRect(a.cx - 20f, a.cy - 20f, a.cx + 20f, a.cy + 20f, p)
            cv.drawLine(a.tipX.toFloat(), a.tipY.toFloat(),
                (a.tipX + a.dx * 40).toFloat(), (a.tipY + a.dy * 40).toFloat(), p)
        }
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private val detector = ArrowDetector()
    private val thread = HandlerThread("bot").also { it.start() }
    private val handler = Handler(thread.looper)
    private val main = Handler(Looper.getMainLooper())
    private val views = ArrayList<View>()
    private var playBtn: Button? = null
    private var lastBmp: Bitmap? = null
    @Volatile private var running = false
    private var sw = 0; private var sh = 0
    private var emptyCount = 0
    private var nextX = -1; private var nextY = -1
    private var started = false
    private val lock = Any()
    private var held: android.media.Image? = null
    @Volatile private var lastFrameTime = 0L
    private var lastTapTime = 0L
    private val capThread = HandlerThread("cap").also { it.start() }
    private val SETTLE_MS = 160L     // انتظر استقرار الشاشة (انتهاء حركة الأسهم) قبل التحليل

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        val ch = "bot"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("MazeBot")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra("data")
        if (data != null && !started) {
            started = true
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data).also {
                it.registerCallback(object : MediaProjection.Callback() {}, handler)
            }
            setupCapture()
            showButtons()
        }
        return START_NOT_STICKY
    }

    private fun setupCapture() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) synchronized(lock) {
                held?.close(); held = img
                lastFrameTime = SystemClock.uptimeMillis()
            }
        }, Handler(capThread.looper))
        vd = projection!!.createVirtualDisplay("cap", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
    }

    private val BTN = 120
    private val LOOP_MS = 300L      // سرعة الدورة (أقل = أسرع)
    private val MAX_TAPS = 3        // عدد الأسهم الحرة المنقورة بكل دورة

    private val FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun floating(label: String, x: Int, y: Int,
                         onClick: (() -> Unit)?, onDrop: ((Int, Int) -> Unit)?): Button {
        val b = Button(this).apply { text = label }
        val lp = WindowManager.LayoutParams(BTN, BTN,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FLAGS, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y
            if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        var ox = 0; var oy = 0; var tx = 0f; var ty = 0f; var moved = false
        var offX = 0; var offY = 0
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ox = lp.x; oy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    val loc = IntArray(2); b.getLocationOnScreen(loc)
                    offX = loc[0] - lp.x; offY = loc[1] - lp.y      // إزاحة النافذة عن الشاشة
                }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - tx) > 10 || Math.abs(e.rawY - ty) > 10) moved = true
                    lp.x = ox + (e.rawX - tx).toInt(); lp.y = oy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(b, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke() else onDrop?.invoke(lp.x + offX + BTN / 2, lp.y + offY + BTN / 2)
            }
            true
        }
        wm.addView(b, lp); views.add(b)
        return b
    }

    private fun showButtons() {
        val y = (sh * 0.91f).toInt()           // أسفل الشاشة حتى لا تغطي اللغز
        playBtn = floating("▶", 20, y, { toggle() }, null)
        floating("🎯", 20 + (BTN + 15), y, null) { sx, sy -> nextX = sx; nextY = sy }
        floating("🐞", 20 + 2 * (BTN + 15), y, { debugShot() }, null)
        floating("✖", 20 + 3 * (BTN + 15), y, { stopSelf() }, null)
    }

    private fun toggle() {
        running = !running
        playBtn?.text = if (running) "■" else "▶"
        emptyCount = 0
        if (running) handler.post(loop) else handler.removeCallbacks(loop)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val t0 = SystemClock.uptimeMillis()
            try { step() } catch (t: Throwable) { t.printStackTrace() }
            val used = SystemClock.uptimeMillis() - t0
            handler.postDelayed(this, maxOf(0L, LOOP_MS - used))
        }
    }

    private fun grab(): Bitmap? {
        val img = synchronized(lock) { val i = held; held = null; i } ?: return lastBmp
        try {
            val p = img.planes[0]
            val rowPad = p.rowStride - p.pixelStride * sw
            val tmp = Bitmap.createBitmap(sw + rowPad / p.pixelStride, sh, Bitmap.Config.ARGB_8888)
            tmp.copyPixelsFromBuffer(p.buffer)
            lastBmp = Bitmap.createBitmap(tmp, 0, 0, sw, sh)
        } finally { img.close() }
        return lastBmp
    }

    private fun step() {
        val now = SystemClock.uptimeMillis()
        // الشاشة لسا تتحرك بعد نقرة؟ انتظر (بحد أقصى 1.5 ثانية)
        if (now - lastFrameTime < SETTLE_MS && now - lastTapTime < 1500) return
        val bmp = grab() ?: return
        val arrows = detector.findArrows(bmp)
        if (arrows.isEmpty()) {
            emptyCount++
            if (emptyCount >= 5 && nextX > 0) {          // المرحلة انتهت => زر التالي
                AutoClickService.tap(nextX, nextY)
                emptyCount = 0
                Thread.sleep(1500)
            }
        } else {
            emptyCount = 0
            val free = arrows.filter { !detector.isBlocked(it) }
            var n = 0
            for (a in free) {
                if (n >= MAX_TAPS || !running) break
                AutoClickService.tap(a.cx, a.cy)
                lastTapTime = SystemClock.uptimeMillis()
                Thread.sleep(110)
                n++
            }
        }
    }

    /** لقطة تشخيص: ترسم مربعات 5 ثواني ثم تختفي */
    private fun debugShot() {
        handler.post {
            val bmp = grab() ?: return@post
            val items = detector.findArrows(bmp).map { it to detector.isBlocked(it) }
            main.post {
                val v = DebugView(this).apply { this.items = items }
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
                if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                wm.addView(v, lp)
                main.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {} }, 5000)
            }
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        vd?.release(); projection?.stop()
        synchronized(lock) { held?.close(); held = null }
        reader?.close(); capThread.quitSafely()
        for (v in views) try { wm.removeView(v) } catch (_: Exception) {}
        thread.quitSafely()
        super.onDestroy()
    }
}
